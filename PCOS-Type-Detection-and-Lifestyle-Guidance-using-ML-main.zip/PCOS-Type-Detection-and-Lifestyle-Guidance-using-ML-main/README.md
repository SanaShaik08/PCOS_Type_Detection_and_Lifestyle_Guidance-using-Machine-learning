# PCOS-Type-Detection-and-Lifestyle-Guidance-using-ML
**PCOS Type Detection and Lifestyle Guidance** is an AI-powered platform that predicts your PCOS type using health data and ultrasound scans. It offers personalized diet, exercise, and wellness plans tailored to your condition, helping you manage symptoms, balance hormones, and improve overall health naturally.
